# TelegramForwarder

一个带中文网页控制台的 Telegram 实时转发工具。

当前支持：

- 多进程实时监听多个频道 / 群
- 多条转发规则同时运行
- 多对多、多对一转发
- 每条规则单独设置关键词过滤
- Bot Token 后台设置并保存到 `.env`
- 项目启动后自动向目标群发送启动通知
- 命中后并发分发，尽量缩短延迟
- 搜索所有已配置源频道的历史消息
- 手动指定账号目标或 Bot 目标进行转发
- Vue 3 中文控制台
- Docker 部署

## 最简单的使用方式

1. 准备 `.env`

至少要有这些字段：

```dotenv
TG_DASHBOARD_PASSWORD=admin
TG_API_ID=你的_api_id
TG_API_HASH=你的_api_hash
TG_SESSION_STRING=
TG_BOT_TOKEN=
# 多个 Bot Token 可用英文逗号分隔，例如 token_1,token_2,token_3
TG_FORWARD_STRATEGY=parallel
TG_STARTUP_NOTIFY_ENABLED=false
```

`TG_FORWARD_STRATEGY` 支持 3 种模式：
- `parallel`：账号目标和 Bot 目标同时转发
- `account_first`：优先账号目标，失败后再回退 Bot 目标
- `bot_first`：优先 Bot 目标，失败后再回退账号目标

多个 Bot Token 也支持，直接填在同一个 `TG_BOT_TOKEN` 里即可：

```dotenv
TG_BOT_TOKEN=bot_token_1,bot_token_2,bot_token_3
```

当转发策略选择 `bot_first` 时，执行顺序就是：

- 先尝试 `bot#1`
- `bot#1` 失败后自动尝试 `bot#2`
- 所有 Bot 都失败后，再回退到用户账号转发

2. 生成 Telegram 登录会话

```powershell
tg-forwarder login --config .env --save-env
```

3. 启动网页控制台

```powershell
tg-forwarder web --config .env --host 0.0.0.0 --port 8080
```

4. 打开浏览器

```text
http://127.0.0.1:8080
```

默认控制台密码：

```text
admin
```

## Docker

启动：

```powershell
docker compose up -d --build
```

打开：

```text
http://127.0.0.1:8080
```

默认密码也是：

```text
admin
```

如果你要在 Docker 里生成 `session_string`：

```powershell
docker compose run --rm tg-forwarder tg-forwarder login --config /workspace/.env --save-env
```

## 后台可以做什么

### 1. 实时自动转发

每条规则都可以设置：

- 规则名称
- 源频道 / 群
- 账号目标频道 / 群
- Bot 目标频道 / 群
- 是否监听编辑后的消息
- 关键词过滤

说明：

- 一条规则只监听一个源
- 一条规则可以转发到多个账号目标
- 一条规则也可以额外转发到多个 Bot 目标
- 多个源请新增多条规则

### 2. Bot Token 后台设置并保存

后台账号配置区里有：

- `API ID`
- `API HASH`
- `SESSION STRING`
- `BOT TOKEN`
- `转发策略`
- `启动通知开关`
- `启动通知内容`

点“保存配置”后，`BOT TOKEN` 会自动写入 `.env` 里的：

```dotenv
TG_BOT_TOKEN=你的_bot_token
```

如果开启了启动通知，还会额外写入：

```dotenv
TG_STARTUP_NOTIFY_ENABLED=true
TG_STARTUP_NOTIFY_MESSAGE="你的启动通知内容"
```

### 3. 搜索所有历史消息

后台有一个“消息搜索”面板：

- 可以搜索所有已配置源频道
- 输入关键词后搜索历史消息
- 关键词留空时，会读取各源频道最近的消息

每条搜索结果都可以看到：

- 来源频道
- 消息 ID
- 时间
- 命中的规则
- 预览内容
- 原消息链接

### 4. 指定转发

搜索结果下面可以直接填写：

- 账号目标
- Bot 目标

然后点“执行指定转发”。

这时可以：

- 只转发到账号目标
- 只转发到 Bot 目标
- 两边一起转发

## Bot 直接转发说明

你这次要的不是“Bot 发摘要通知”，而是“Bot 直接发对应消息”。

现在的逻辑是：

1. 自动规则命中后，如果配置了 `BOT TOKEN` 和规则里的 `Bot 目标`
2. 系统会优先尝试让 Bot 直接转发原消息
3. 如果 Telegram 权限或来源限制导致 Bot 不能直接 forward
4. 就回退为 Bot 复制消息内容 / 媒体后再发到目标

所以最终效果仍然是：

- 消息由 Bot 发到 Bot 目标
- 尽量保持和原消息一致

注意：

- Bot 本身不能稳定替代用户号去监听所有频道，所以“监听源消息”仍然建议用 `session_string`
- Bot 要能发到目标群 / 频道，前提是它已经被拉进去并拥有发送权限

## 如何测试

推荐先用测试群 / 测试频道。

### 测试实时自动转发

1. 用账号 A 生成 `session_string`
2. 让账号 A 加入源群和目标群
3. 如果要测 Bot 转发，再把 Bot 拉进 Bot 目标群并给发送权限
4. 在后台新增一条规则
5. 保存配置
6. 校验配置
7. 启动后端
8. 用账号 B 往源群发消息
9. 看目标群和 Bot 目标是否收到

注意：

- 程序会忽略当前登录账号自己发出的消息
- 所以测试时最好用另一个账号发消息

### 测试历史搜索 + 指定转发

1. 打开“消息搜索”
2. 输入关键词，或者留空
3. 点“搜索所有源”
4. 找到目标消息
5. 填写账号目标或 Bot 目标
6. 点“执行指定转发”

## 常见问题

### 1. 提示 `simple mode requires TG_SOURCE_CHAT`

说明你现在还是旧的单规则模式，而且没有填写源频道。

如果你用网页控制台，直接在“转发规则”里新增规则并保存即可。

如果你仍然想用旧单规则模式，请在 `.env` 里填写：

```dotenv
TG_SOURCE_CHAT=@你的源频道
TG_TARGET_CHATS=@目标频道1,@目标频道2
TG_BOT_TARGET_CHATS=@bot_target
```

### 2. 多条规则保存在哪里

网页控制台会把规则自动写进 `.env` 里的 `TG_RULES_JSON`，不用手动维护。

### 3. 规则改了要不要重启

建议改完后点一次“重启后端”，最省心。
