from __future__ import annotations

from dataclasses import dataclass, field
import re

from telethon.tl.custom.message import Message

from tg_forwarder.config import (
    CONTENT_MATCH_MODE_ANY,
    FilterConfig,
    LANDING_PAGE_EXTRACT_MODE_SECTION,
    RESOURCE_PRESET_115CDN,
    RESOURCE_PRESET_ALIYUN,
    RESOURCE_PRESET_BAIDU,
    RESOURCE_PRESET_ED2K,
    RESOURCE_PRESET_MAGNET,
    RESOURCE_PRESET_QUARK,
    RESOURCE_PRESET_THUNDER,
)
from tg_forwarder.message_index import (
    LandingPageInspection,
    LandingPageReference,
    extract_message_keyword_values,
    extract_message_landing_page_refs,
    extract_message_text_values,
    get_landing_page_behavior,
    inspect_message_landing_pages,
)


MATCH_VIA_NONE = "none"
MATCH_VIA_MESSAGE = "message"
MATCH_VIA_LANDING_PAGE = "landing_page"
MATCH_VIA_COMBINED = "message+landing_page"
RESOURCE_PRESET_REGEX_PATTERNS = {
    RESOURCE_PRESET_115CDN: ("资源:115", r"(?:https?://)?(?:www\.)?115cdn\.com/"),
    RESOURCE_PRESET_ED2K: ("资源:ed2k", r"ed2k://\|file\|"),
    RESOURCE_PRESET_MAGNET: ("资源:magnet", r"magnet:\?xt="),
    RESOURCE_PRESET_THUNDER: ("资源:thunder", r"thunder://"),
    RESOURCE_PRESET_QUARK: ("资源:夸克/UC", r"(?:pan\.quark\.cn|drive\.uc\.cn)"),
    RESOURCE_PRESET_ALIYUN: ("资源:阿里云盘", r"(?:aliyundrive\.com|alipan\.com)"),
    RESOURCE_PRESET_BAIDU: ("资源:百度网盘", r"(?:pan\.baidu\.com|yun\.baidu\.com)"),
}


@dataclass(slots=True)
class KeywordEvaluationResult:
    matched: bool
    matched_any: list[str] = field(default_factory=list)
    matched_all: list[str] = field(default_factory=list)
    blocked: list[str] = field(default_factory=list)
    missing_all: list[str] = field(default_factory=list)


@dataclass(slots=True)
class MessageMatchResult:
    matched: bool
    matched_via: str = MATCH_VIA_NONE
    matched_any: list[str] = field(default_factory=list)
    matched_all: list[str] = field(default_factory=list)
    blocked: list[str] = field(default_factory=list)
    missing_all: list[str] = field(default_factory=list)
    landing_page_refs: list[LandingPageReference] = field(default_factory=list)
    landing_pages: list[LandingPageInspection] = field(default_factory=list)
    has_media: bool = False
    has_text: bool = False
    missing_content_parts: list[str] = field(default_factory=list)


async def message_matches(message: Message, filters: FilterConfig) -> bool:
    return (await explain_message_match(message, filters)).matched


async def explain_message_match(message: Message, filters: FilterConfig) -> MessageMatchResult:
    if getattr(message, "action", None) is not None:
        return MessageMatchResult(matched=False)

    has_media = bool(message.media)
    text_values = extract_message_text_values(message)
    has_text = bool(text_values)
    landing_page_refs = (
        extract_message_landing_page_refs(message) if filters.include_landing_pages else []
    )
    missing_content_parts = collect_missing_content_parts(
        filters=filters,
        has_media=has_media,
        has_text=has_text,
    )

    selected_conditions: list[bool] = []
    if filters.media_only:
        selected_conditions.append(has_media)
    if filters.text_only:
        selected_conditions.append(has_text)
    if selected_conditions:
        if filters.content_match_mode == CONTENT_MATCH_MODE_ANY:
            if not any(selected_conditions):
                return MessageMatchResult(
                    matched=False,
                    landing_page_refs=landing_page_refs,
                    has_media=has_media,
                    has_text=has_text,
                    missing_content_parts=missing_content_parts,
                )
        elif not all(selected_conditions):
            return MessageMatchResult(
                matched=False,
                landing_page_refs=landing_page_refs,
                has_media=has_media,
                has_text=has_text,
                missing_content_parts=missing_content_parts,
            )

    if not has_advanced_filters(filters):
        return MessageMatchResult(
            matched=True,
            matched_via=MATCH_VIA_MESSAGE,
            landing_page_refs=landing_page_refs,
            has_media=has_media,
            has_text=has_text,
        )

    keyword_values = extract_message_keyword_values(message)
    haystacks = build_keyword_haystacks(keyword_values, filters.case_sensitive)
    regex_haystacks = build_regex_haystacks(keyword_values)
    keywords_any = build_keyword_specs(filters.keywords_any, filters.case_sensitive)
    keywords_all = build_keyword_specs(filters.keywords_all, filters.case_sensitive)
    block_keywords = build_keyword_specs(filters.block_keywords, filters.case_sensitive)
    regex_any = build_regex_specs(filters.regex_any, filters.case_sensitive)
    regex_any.extend(build_resource_preset_specs(filters.resource_presets, filters.case_sensitive))
    regex_all = build_regex_specs(filters.regex_all, filters.case_sensitive)
    block_regex = build_regex_specs(filters.regex_block, filters.case_sensitive)

    local_result = evaluate_keyword_filters_detailed(
        haystacks=haystacks,
        regex_haystacks=regex_haystacks,
        keywords_any=keywords_any,
        keywords_all=keywords_all,
        block_keywords=block_keywords,
        regex_any=regex_any,
        regex_all=regex_all,
        block_regex=block_regex,
    )
    if local_result.blocked:
        return build_message_match_result(
            matched=False,
            source=MATCH_VIA_MESSAGE,
            evaluation=local_result,
            landing_page_refs=landing_page_refs,
            has_media=has_media,
            has_text=has_text,
            missing_content_parts=missing_content_parts,
        )
    if not filters.include_landing_pages or not landing_page_refs:
        return build_message_match_result(
            matched=local_result.matched,
            source=MATCH_VIA_MESSAGE if local_result.matched else MATCH_VIA_NONE,
            evaluation=local_result,
            landing_page_refs=landing_page_refs,
            has_media=has_media,
            has_text=has_text,
            missing_content_parts=missing_content_parts,
        )

    landing_pages = await inspect_message_landing_pages(message)
    landing_page_values: list[str] = []
    for page in landing_pages:
        landing_page_values.extend(page.values)
    if not landing_page_values:
        return build_message_match_result(
            matched=local_result.matched,
            source=MATCH_VIA_MESSAGE if local_result.matched else MATCH_VIA_NONE,
            evaluation=local_result,
            landing_page_refs=landing_page_refs,
            landing_pages=landing_pages,
            has_media=has_media,
            has_text=has_text,
            missing_content_parts=missing_content_parts,
        )

    landing_haystacks = build_keyword_haystacks(landing_page_values, filters.case_sensitive)
    landing_regex_haystacks = build_regex_haystacks(landing_page_values)
    landing_result = evaluate_keyword_filters_detailed(
        haystacks=landing_haystacks,
        regex_haystacks=landing_regex_haystacks,
        keywords_any=keywords_any,
        keywords_all=keywords_all,
        block_keywords=block_keywords,
        regex_any=regex_any,
        regex_all=regex_all,
        block_regex=block_regex,
    )
    if landing_result.blocked:
        return build_message_match_result(
            matched=False,
            source=MATCH_VIA_LANDING_PAGE,
            evaluation=landing_result,
            landing_page_refs=landing_page_refs,
            landing_pages=landing_pages,
            has_media=has_media,
            has_text=has_text,
            missing_content_parts=missing_content_parts,
        )

    merged_haystacks = build_keyword_haystacks(
        list(keyword_values) + list(landing_page_values),
        filters.case_sensitive,
    )
    merged_regex_haystacks = build_regex_haystacks(list(keyword_values) + list(landing_page_values))
    merged_result = evaluate_keyword_filters_detailed(
        haystacks=merged_haystacks,
        regex_haystacks=merged_regex_haystacks,
        keywords_any=keywords_any,
        keywords_all=keywords_all,
        block_keywords=block_keywords,
        regex_any=regex_any,
        regex_all=regex_all,
        block_regex=block_regex,
    )
    if merged_result.blocked:
        return build_message_match_result(
            matched=False,
            source=MATCH_VIA_COMBINED,
            evaluation=merged_result,
            landing_page_refs=landing_page_refs,
            landing_pages=landing_pages,
            has_media=has_media,
            has_text=has_text,
            missing_content_parts=missing_content_parts,
        )
    if merged_result.matched and local_result.matched and landing_result.matched:
        return build_message_match_result(
            matched=True,
            source=MATCH_VIA_COMBINED,
            evaluation=merged_result,
            landing_page_refs=landing_page_refs,
            landing_pages=landing_pages,
            has_media=has_media,
            has_text=has_text,
            missing_content_parts=missing_content_parts,
        )
    if landing_result.matched:
        return build_message_match_result(
            matched=True,
            source=MATCH_VIA_LANDING_PAGE,
            evaluation=landing_result,
            landing_page_refs=landing_page_refs,
            landing_pages=landing_pages,
            has_media=has_media,
            has_text=has_text,
            missing_content_parts=missing_content_parts,
        )
    if merged_result.matched:
        return build_message_match_result(
            matched=True,
            source=MATCH_VIA_COMBINED,
            evaluation=merged_result,
            landing_page_refs=landing_page_refs,
            landing_pages=landing_pages,
            has_media=has_media,
            has_text=has_text,
            missing_content_parts=missing_content_parts,
        )
    if local_result.matched:
        return build_message_match_result(
            matched=True,
            source=MATCH_VIA_MESSAGE,
            evaluation=local_result,
            landing_page_refs=landing_page_refs,
            landing_pages=landing_pages,
            has_media=has_media,
            has_text=has_text,
            missing_content_parts=missing_content_parts,
        )
    return build_message_match_result(
        matched=False,
        source=MATCH_VIA_NONE,
        evaluation=merged_result,
        landing_page_refs=landing_page_refs,
        landing_pages=landing_pages,
        has_media=has_media,
        has_text=has_text,
        missing_content_parts=missing_content_parts,
    )


def build_message_match_result(
    *,
    matched: bool,
    source: str,
    evaluation: KeywordEvaluationResult,
    landing_page_refs: list[LandingPageReference],
    landing_pages: list[LandingPageInspection] | None = None,
    has_media: bool = False,
    has_text: bool = False,
    missing_content_parts: list[str] | None = None,
) -> MessageMatchResult:
    return MessageMatchResult(
        matched=matched,
        matched_via=source,
        matched_any=list(evaluation.matched_any),
        matched_all=list(evaluation.matched_all),
        blocked=list(evaluation.blocked),
        missing_all=list(evaluation.missing_all),
        landing_page_refs=list(landing_page_refs),
        landing_pages=list(landing_pages or []),
        has_media=has_media,
        has_text=has_text,
        missing_content_parts=list(missing_content_parts or []),
    )


def build_match_note(match_result: MessageMatchResult) -> str | None:
    parts: list[str] = []

    source_label = {
        MATCH_VIA_MESSAGE: "原消息",
        MATCH_VIA_LANDING_PAGE: "落地页",
        MATCH_VIA_COMBINED: "原消息+落地页",
    }.get(match_result.matched_via)
    if source_label:
        parts.append(f"命中来源={source_label}")

    if match_result.matched_all:
        parts.append(f"全部条件={','.join(match_result.matched_all)}")
    if match_result.matched_any:
        parts.append(f"任一条件={','.join(match_result.matched_any)}")

    if match_result.landing_page_refs:
        hosts = dedupe_strings([item.host for item in match_result.landing_page_refs])
        parts.append(f"识别落地页={','.join(hosts)}")
        parts.extend(build_landing_page_runtime_parts())

    if match_result.matched_via in {MATCH_VIA_LANDING_PAGE, MATCH_VIA_COMBINED}:
        urls = [item.url for item in match_result.landing_pages if item.values]
        if not urls:
            urls = [item.url for item in match_result.landing_page_refs]
        if urls:
            parts.append(f"命中页面={'; '.join(urls[:2])}")

    return " | ".join(parts) or None


def build_mismatch_note(match_result: MessageMatchResult, filters: FilterConfig) -> str | None:
    parts: list[str] = []
    any_labels = build_positive_any_labels(filters)
    all_labels = build_required_all_labels(filters)

    if match_result.blocked:
        parts.append(f"未命中原因=命中黑名单条件:{','.join(match_result.blocked)}")
        landing_parts = build_landing_page_debug_parts_v2(match_result)
        if landing_parts:
            parts.extend(landing_parts)
        return " | ".join(parts)

    if match_result.missing_content_parts:
        content_reason = build_content_mismatch_reason(
            filters=filters,
            missing_parts=match_result.missing_content_parts,
            has_media=match_result.has_media,
            has_text=match_result.has_text,
        )
        if content_reason:
            parts.append(f"未命中原因={content_reason}")

    if all_labels and match_result.missing_all:
        parts.append(f"未命中原因=缺少全部条件:{','.join(match_result.missing_all)}")

    if any_labels and not match_result.matched_any:
        parts.append(f"未命中原因=未命中任一条件:{','.join(any_labels)}")

    landing_parts = build_landing_page_debug_parts_v2(match_result)
    if landing_parts:
        parts.extend(landing_parts)

    if not parts:
        parts.append("未命中原因=未通过当前规则")
    return " | ".join(parts)


def collect_missing_content_parts(
    *,
    filters: FilterConfig,
    has_media: bool,
    has_text: bool,
) -> list[str]:
    missing_parts: list[str] = []
    if filters.media_only and not has_media:
        missing_parts.append("media")
    if filters.text_only and not has_text:
        missing_parts.append("text")
    return missing_parts


def build_content_mismatch_reason(
    *,
    filters: FilterConfig,
    missing_parts: list[str],
    has_media: bool,
    has_text: bool,
) -> str | None:
    if not missing_parts:
        return None

    if filters.content_match_mode == CONTENT_MATCH_MODE_ANY and filters.media_only and filters.text_only:
        if not has_media and not has_text:
            return "需要媒体或文字其一，但当前既无媒体也无文字"

    labels = {
        "media": "媒体",
        "text": "文字",
    }
    missing_labels = [labels[item] for item in missing_parts if item in labels]
    if not missing_labels:
        return None
    if len(missing_labels) == 1:
        return f"缺少{missing_labels[0]}条件"
    return f"缺少{'和'.join(missing_labels)}条件"


def build_landing_page_mismatch_parts(match_result: MessageMatchResult) -> list[str]:
    parts: list[str] = []
    if match_result.landing_page_refs:
        hosts = dedupe_strings([item.host for item in match_result.landing_page_refs])
        if hosts:
            parts.append(f"已识别落地页={','.join(hosts)}")
            parts.extend(build_landing_page_runtime_parts())

    if match_result.matched_via in {MATCH_VIA_LANDING_PAGE, MATCH_VIA_COMBINED}:
        urls = [item.url for item in match_result.landing_pages if item.values]
        if not urls:
            urls = [item.url for item in match_result.landing_page_refs]
        if urls:
            parts.append(f"已检查页面={'; '.join(urls[:2])}")
    return parts


def build_landing_page_debug_parts(match_result: MessageMatchResult) -> list[str]:
    parts = build_landing_page_mismatch_parts(match_result)

    if match_result.landing_pages:
        extracted_value_count = sum(len(item.values) for item in match_result.landing_pages)
        if extracted_value_count > 0:
            parts.append(f"落地页提取={extracted_value_count} 项")
        else:
            parts.append("落地页未提取到可用内容")

        failed_pages = [item for item in match_result.landing_pages if item.error_message]
        if failed_pages:
            parts.append(f"落地页抓取失败={failed_pages[0].error_message}")

    return parts


def build_landing_page_debug_parts_v2(match_result: MessageMatchResult) -> list[str]:
    parts: list[str] = []

    if match_result.landing_page_refs:
        hosts = dedupe_strings([item.host for item in match_result.landing_page_refs])
        if hosts:
            parts.append(f"已识别落地页={','.join(hosts)}")
            parts.extend(build_landing_page_runtime_parts())

    urls = [item.url for item in match_result.landing_pages]
    if not urls:
        urls = [item.url for item in match_result.landing_page_refs]
    if urls:
        parts.append(f"已检查页面={'; '.join(urls[:2])}")

    if match_result.landing_pages:
        extracted_value_count = sum(len(item.values) for item in match_result.landing_pages)
        if extracted_value_count > 0:
            parts.append(f"落地页提取={extracted_value_count} 项")
        else:
            parts.append("落地页未提取到可用内容")

        failed_pages = [item for item in match_result.landing_pages if item.error_message]
        if failed_pages:
            parts.append(f"落地页抓取失败={failed_pages[0].error_message}")

    return parts


def build_landing_page_runtime_parts() -> list[str]:
    enabled, _, extract_mode, section_markers, stop_markers, fallback_to_full = (
        get_landing_page_behavior()
    )
    if not enabled:
        return []

    if extract_mode == LANDING_PAGE_EXTRACT_MODE_SECTION:
        parts = ["落地页提取模式=指定段"]
        if section_markers:
            parts.append(
                f"起始标记={format_marker_preview(section_markers)}"
            )
        if stop_markers:
            parts.append(
                f"结束标记={format_marker_preview(stop_markers)}"
            )
        parts.append(
            f"未命中标记回退整页={'开启' if fallback_to_full else '关闭'}"
        )
        return parts

    return ["落地页提取模式=整页"]


def format_marker_preview(markers: list[str], limit: int = 3) -> str:
    preview = [str(item or "").strip() for item in markers if str(item or "").strip()]
    if not preview:
        return "-"
    if len(preview) <= limit:
        return ",".join(preview)
    return ",".join(preview[:limit]) + f" 等{len(preview)}项"


def build_keyword_haystacks(raw_values: list[str], case_sensitive: bool) -> list[str]:
    if case_sensitive:
        return [str(value or "") for value in raw_values]
    return [str(value or "").lower() for value in raw_values]


def build_keyword_specs(raw_values: list[str], case_sensitive: bool) -> list[tuple[str, str]]:
    if case_sensitive:
        return [(value, value) for value in raw_values]
    return [(value, value.lower()) for value in raw_values]


def build_regex_haystacks(raw_values: list[str]) -> list[str]:
    return [str(value or "") for value in raw_values]


def build_regex_specs(raw_values: list[str], case_sensitive: bool) -> list[tuple[str, re.Pattern[str]]]:
    flags = 0 if case_sensitive else re.IGNORECASE
    return [(format_regex_label(value), re.compile(value, flags)) for value in raw_values]


def build_resource_preset_specs(
    raw_values: list[str],
    case_sensitive: bool,
) -> list[tuple[str, re.Pattern[str]]]:
    flags = 0 if case_sensitive else re.IGNORECASE
    specs: list[tuple[str, re.Pattern[str]]] = []
    for item in raw_values:
        preset = RESOURCE_PRESET_REGEX_PATTERNS.get(item)
        if not preset:
            continue
        label, pattern = preset
        specs.append((label, re.compile(pattern, flags)))
    return specs


def format_regex_label(pattern: str) -> str:
    return f"正则:{pattern}"


def format_resource_preset_label(preset: str) -> str:
    spec = RESOURCE_PRESET_REGEX_PATTERNS.get(preset)
    if spec:
        return spec[0]
    return f"资源:{preset}"


def build_positive_any_labels(filters: FilterConfig) -> list[str]:
    return dedupe_strings(
        list(filters.keywords_any)
        + [format_regex_label(item) for item in filters.regex_any]
        + [format_resource_preset_label(item) for item in filters.resource_presets]
    )


def build_required_all_labels(filters: FilterConfig) -> list[str]:
    return dedupe_strings(
        list(filters.keywords_all)
        + [format_regex_label(item) for item in filters.regex_all]
    )


def has_advanced_filters(filters: FilterConfig) -> bool:
    return bool(
        filters.keywords_any
        or filters.keywords_all
        or filters.block_keywords
        or filters.regex_any
        or filters.regex_all
        or filters.regex_block
        or filters.resource_presets
    )


def evaluate_keyword_filters(
    *,
    haystacks: list[str],
    regex_haystacks: list[str],
    keywords_any: list[tuple[str, str]],
    keywords_all: list[tuple[str, str]],
    block_keywords: list[tuple[str, str]],
    regex_any: list[tuple[str, re.Pattern[str]]],
    regex_all: list[tuple[str, re.Pattern[str]]],
    block_regex: list[tuple[str, re.Pattern[str]]],
) -> bool:
    return evaluate_keyword_filters_detailed(
        haystacks=haystacks,
        regex_haystacks=regex_haystacks,
        keywords_any=keywords_any,
        keywords_all=keywords_all,
        block_keywords=block_keywords,
        regex_any=regex_any,
        regex_all=regex_all,
        block_regex=block_regex,
    ).matched


def evaluate_keyword_filters_detailed(
    *,
    haystacks: list[str],
    regex_haystacks: list[str],
    keywords_any: list[tuple[str, str]],
    keywords_all: list[tuple[str, str]],
    block_keywords: list[tuple[str, str]],
    regex_any: list[tuple[str, re.Pattern[str]]],
    regex_all: list[tuple[str, re.Pattern[str]]],
    block_regex: list[tuple[str, re.Pattern[str]]],
) -> KeywordEvaluationResult:
    matched_block = [raw for raw, needle in block_keywords if any(needle in haystack for haystack in haystacks)]
    matched_block.extend(
        raw for raw, pattern in block_regex if any(pattern.search(haystack) for haystack in regex_haystacks)
    )
    if matched_block:
        return KeywordEvaluationResult(matched=False, blocked=dedupe_strings(matched_block))

    matched_all = [raw for raw, needle in keywords_all if any(needle in haystack for haystack in haystacks)]
    matched_all.extend(
        raw for raw, pattern in regex_all if any(pattern.search(haystack) for haystack in regex_haystacks)
    )
    missing_all = [raw for raw, needle in keywords_all if not any(needle in haystack for haystack in haystacks)]
    missing_all.extend(
        raw for raw, pattern in regex_all if not any(pattern.search(haystack) for haystack in regex_haystacks)
    )
    total_all_count = len(keywords_all) + len(regex_all)
    if total_all_count and len(dedupe_strings(matched_all)) == total_all_count:
        return KeywordEvaluationResult(
            matched=True,
            matched_all=dedupe_strings(matched_all),
            missing_all=dedupe_strings(missing_all),
        )

    matched_any = [raw for raw, needle in keywords_any if any(needle in haystack for haystack in haystacks)]
    matched_any.extend(
        raw for raw, pattern in regex_any if any(pattern.search(haystack) for haystack in regex_haystacks)
    )
    if matched_any:
        return KeywordEvaluationResult(
            matched=True,
            matched_any=dedupe_strings(matched_any),
            matched_all=dedupe_strings(matched_all),
            missing_all=dedupe_strings(missing_all),
        )

    if keywords_all or keywords_any or regex_all or regex_any:
        return KeywordEvaluationResult(
            matched=False,
            matched_all=dedupe_strings(matched_all),
            missing_all=dedupe_strings(missing_all),
        )
    return KeywordEvaluationResult(matched=True)


def dedupe_strings(values: list[str]) -> list[str]:
    result: list[str] = []
    seen: set[str] = set()
    for value in values:
        text = str(value or "").strip()
        if not text or text in seen:
            continue
        seen.add(text)
        result.append(text)
    return result
