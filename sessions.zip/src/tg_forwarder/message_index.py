from __future__ import annotations

import asyncio
from dataclasses import dataclass
import gzip
from html.parser import HTMLParser
from http.client import HTTPResponse
import io
import re
import socket
import ssl as ssl_mod
import threading
import time
from telethon.tl.custom.message import Message
from urllib.error import URLError
from urllib.parse import quote, urljoin, urlparse, urlsplit, urlunsplit
from urllib.request import Request, urlopen

from tg_forwarder.config import (
    DEFAULT_LANDING_PAGE_HOSTS,
    LANDING_PAGE_EXTRACT_MODE_FULL,
    LANDING_PAGE_EXTRACT_MODE_SECTION,
    ProxyConfig,
)


try:
    import python_socks
except ImportError:
    python_socks = None

try:
    import socks
except ImportError:
    socks = None


INSPECTABLE_LANDING_PAGE_HOSTS = set(DEFAULT_LANDING_PAGE_HOSTS)
LANDING_PAGE_CACHE_TTL_SECONDS = 600
LANDING_PAGE_FETCH_TIMEOUT_SECONDS = 6
LANDING_PAGE_MAX_REDIRECTS = 3
_LANDING_PAGE_CACHE: dict[str, tuple[float, list[str]]] = {}
_LANDING_PAGE_CACHE_LOCK = threading.Lock()
_LANDING_PAGE_ENABLED = True
_LANDING_PAGE_HOSTS: set[str] = set(INSPECTABLE_LANDING_PAGE_HOSTS)
_LANDING_PAGE_EXTRACT_MODE = LANDING_PAGE_EXTRACT_MODE_FULL
_LANDING_PAGE_SECTION_MARKERS: list[str] = []
_LANDING_PAGE_SECTION_STOP_MARKERS: list[str] = []
_LANDING_PAGE_SECTION_FALLBACK_TO_FULL = True
_LANDING_PAGE_SETTINGS_LOCK = threading.Lock()
_LANDING_PAGE_PROXY_POOL: list[ProxyConfig] = []
_LANDING_PAGE_PROXY_POOL_LOCK = threading.Lock()
HTTP_URL_PATTERN = re.compile(r"https?://[^\s<>'\"]+", re.IGNORECASE)
ED2K_URL_PATTERN = re.compile(r"ed2k://[^\s<>'\"]+", re.IGNORECASE)
MAGNET_URL_PATTERN = re.compile(r"magnet:\?[^\s<>'\"]+", re.IGNORECASE)
THUNDER_URL_PATTERN = re.compile(r"thunder://[^\s<>'\"]+", re.IGNORECASE)
SPECIAL_URL_PATTERNS = (
    HTTP_URL_PATTERN,
    ED2K_URL_PATTERN,
    MAGNET_URL_PATTERN,
    THUNDER_URL_PATTERN,
)


@dataclass(frozen=True, slots=True)
class LandingPageReference:
    url: str
    host: str


@dataclass(slots=True)
class LandingPageInspection:
    url: str
    host: str
    values: list[str]
    error_message: str | None = None


def extract_message_text_values(message: Message) -> list[str]:
    values = [
        getattr(message, "raw_text", ""),
        getattr(message, "message", ""),
        getattr(message, "text", ""),
    ]
    return dedupe_non_empty_strings(values)


def extract_message_keyword_values(message: Message) -> list[str]:
    values = list(extract_message_text_values(message))
    values.extend(extract_message_button_values(message))
    extracted_links: list[str] = []
    for item in values:
        extracted_links.extend(extract_urls_from_text(str(item or "")))
    values.extend(extracted_links)
    return dedupe_non_empty_strings(values)


async def extract_message_landing_page_values(message: Message) -> list[str]:
    values: list[str] = []
    for page in await inspect_message_landing_pages(message):
        values.extend(page.values)
    return dedupe_non_empty_strings(values)


def extract_message_button_values(message: Message) -> list[str]:
    raw_buttons = getattr(message, "buttons", None) or []
    values: list[str] = []
    for row in raw_buttons:
        if isinstance(row, (list, tuple)):
            buttons = row
        else:
            buttons = [row]
        for button in buttons:
            values.extend(
                dedupe_non_empty_strings(
                    [
                        getattr(button, "text", ""),
                        getattr(button, "url", ""),
                        getattr(button, "inline_query", ""),
                        getattr(getattr(button, "button", None), "url", ""),
                    ]
                )
            )
    return dedupe_non_empty_strings(values)


def extract_message_landing_page_urls(message: Message) -> list[str]:
    return [item.url for item in extract_message_landing_page_refs(message)]


def extract_message_landing_page_refs(message: Message) -> list[LandingPageReference]:
    refs: list[LandingPageReference] = []
    candidate_values = [
        *extract_message_text_values(message),
        *extract_message_button_values(message),
    ]
    for raw_value in candidate_values:
        text = str(raw_value or "").strip()
        if not text:
            continue
        for url in extract_urls_from_text(text):
            host = get_inspectable_landing_page_host(url)
            if host:
                refs.append(LandingPageReference(url=url, host=host))
    return dedupe_landing_page_references(refs)


async def inspect_message_landing_pages(message: Message) -> list[LandingPageInspection]:
    refs = extract_message_landing_page_refs(message)
    if not refs:
        return []
    results = await asyncio.gather(
        *(extract_landing_page_values(item.url) for item in refs),
        return_exceptions=True,
    )
    inspections: list[LandingPageInspection] = []
    for ref, result in zip(refs, results):
        values: list[str] = []
        error_message: str | None = None
        if not isinstance(result, Exception):
            values = dedupe_non_empty_strings(result)
        else:
            error_text = str(result).strip()
            error_message = (
                f"{result.__class__.__name__}: {error_text}"
                if error_text
                else result.__class__.__name__
            )
        inspections.append(
            LandingPageInspection(
                url=ref.url,
                host=ref.host,
                values=values,
                error_message=error_message,
            )
        )
    return inspections


async def extract_landing_page_values(url: str) -> list[str]:
    cached = get_cached_landing_page_values(url)
    if cached is not None:
        return cached

    proxy_pool = get_landing_page_proxy_pool()
    if proxy_pool:
        values = await fetch_landing_page_values_via_proxy_pool(url, proxy_pool)
    else:
        values = await asyncio.to_thread(fetch_landing_page_values, url)

    set_cached_landing_page_values(url, values)
    return values


def get_cached_landing_page_values(url: str) -> list[str] | None:
    now = time.monotonic()
    with _LANDING_PAGE_CACHE_LOCK:
        cached = _LANDING_PAGE_CACHE.get(url)
        if cached is None:
            return None
        expires_at, values = cached
        if expires_at <= now:
            _LANDING_PAGE_CACHE.pop(url, None)
            return None
        return list(values)


def set_cached_landing_page_values(url: str, values: list[str]) -> None:
    with _LANDING_PAGE_CACHE_LOCK:
        _LANDING_PAGE_CACHE[url] = (
            time.monotonic() + LANDING_PAGE_CACHE_TTL_SECONDS,
            list(values),
        )


def configure_landing_page_proxy_pool(proxies: list[ProxyConfig] | None) -> None:
    normalized = [item for item in (proxies or []) if item is not None]
    with _LANDING_PAGE_PROXY_POOL_LOCK:
        _LANDING_PAGE_PROXY_POOL.clear()
        _LANDING_PAGE_PROXY_POOL.extend(normalized)


def configure_landing_page_behavior(
    *,
    enabled: bool | None = None,
    hosts: list[str] | None = None,
    extract_mode: str | None = None,
    section_markers: list[str] | None = None,
    section_stop_markers: list[str] | None = None,
    section_fallback_to_full: bool | None = None,
) -> None:
    global _LANDING_PAGE_ENABLED, _LANDING_PAGE_HOSTS
    global _LANDING_PAGE_EXTRACT_MODE, _LANDING_PAGE_SECTION_MARKERS
    global _LANDING_PAGE_SECTION_STOP_MARKERS, _LANDING_PAGE_SECTION_FALLBACK_TO_FULL
    with _LANDING_PAGE_SETTINGS_LOCK:
        if enabled is not None:
            _LANDING_PAGE_ENABLED = bool(enabled)
        if hosts is not None:
            _LANDING_PAGE_HOSTS = {
                str(item or "").strip().lower()
                for item in hosts
                if str(item or "").strip()
            }
        if extract_mode is not None:
            _LANDING_PAGE_EXTRACT_MODE = str(extract_mode or "").strip() or LANDING_PAGE_EXTRACT_MODE_FULL
        if section_markers is not None:
            _LANDING_PAGE_SECTION_MARKERS = [
                str(item or "").strip()
                for item in section_markers
                if str(item or "").strip()
            ]
        if section_stop_markers is not None:
            _LANDING_PAGE_SECTION_STOP_MARKERS = [
                str(item or "").strip()
                for item in section_stop_markers
                if str(item or "").strip()
            ]
        if section_fallback_to_full is not None:
            _LANDING_PAGE_SECTION_FALLBACK_TO_FULL = bool(section_fallback_to_full)


def get_landing_page_behavior() -> tuple[bool, set[str], str, list[str], list[str], bool]:
    with _LANDING_PAGE_SETTINGS_LOCK:
        return (
            _LANDING_PAGE_ENABLED,
            set(_LANDING_PAGE_HOSTS),
            _LANDING_PAGE_EXTRACT_MODE,
            list(_LANDING_PAGE_SECTION_MARKERS),
            list(_LANDING_PAGE_SECTION_STOP_MARKERS),
            _LANDING_PAGE_SECTION_FALLBACK_TO_FULL,
        )


def get_landing_page_proxy_pool() -> list[ProxyConfig]:
    with _LANDING_PAGE_PROXY_POOL_LOCK:
        return list(_LANDING_PAGE_PROXY_POOL)


def fetch_landing_page_values(url: str) -> list[str]:
    html = fetch_landing_page_html(url)
    return extract_landing_page_values_from_html(html)


def fetch_landing_page_html(url: str) -> str:
    normalized_url = normalize_url_for_request(url)
    request = Request(
        normalized_url,
        headers={
            "User-Agent": "TelegramForwarder/0.1.0",
        },
    )
    with urlopen(request, timeout=LANDING_PAGE_FETCH_TIMEOUT_SECONDS) as response:
        charset = response.headers.get_content_charset() or "utf-8"
        return response.read().decode(charset, errors="ignore")


async def fetch_landing_page_values_via_proxy_pool(
    url: str,
    proxy_pool: list[ProxyConfig],
) -> list[str]:
    html = await fetch_landing_page_html_via_proxy_pool(url, proxy_pool)
    return extract_landing_page_values_from_html(html)


async def fetch_landing_page_html_via_proxy_pool(
    url: str,
    proxy_pool: list[ProxyConfig],
) -> str:
    normalized_url = normalize_url_for_request(url)
    last_error: Exception | None = None
    for proxy in proxy_pool:
        try:
            return await fetch_landing_page_html_via_proxy(
                normalized_url,
                proxy,
                redirect_limit=LANDING_PAGE_MAX_REDIRECTS,
            )
        except Exception as exc:
            last_error = exc

    if last_error is not None:
        raise last_error
    return await asyncio.to_thread(fetch_landing_page_html, normalized_url)


async def fetch_landing_page_html_via_proxy(
    url: str,
    proxy: ProxyConfig,
    *,
    redirect_limit: int,
) -> str:
    if redirect_limit < 0:
        raise URLError("too many landing page redirects")

    parsed = urlsplit(url)
    scheme = (parsed.scheme or "").lower()
    host = parsed.hostname or ""
    if scheme not in {"http", "https"} or not host:
        raise URLError(f"unsupported landing page url: {url}")

    port = parsed.port or (443 if scheme == "https" else 80)
    raw_socket = await open_socket_via_proxy(proxy, host=host, port=port)
    try:
        try:
            raw_socket.setblocking(False)
        except Exception:
            pass

        ssl_context = ssl_mod.create_default_context() if scheme == "https" else None
        if ssl_context is not None:
            reader, writer = await asyncio.open_connection(
                sock=raw_socket,
                ssl=ssl_context,
                server_hostname=host,
            )
        else:
            reader, writer = await asyncio.open_connection(sock=raw_socket)

        try:
            request_target = build_http_request_target(parsed.path, parsed.query)
            host_header = parsed.netloc or host
            request_text = (
                f"GET {request_target} HTTP/1.1\r\n"
                f"Host: {host_header}\r\n"
                "User-Agent: TelegramForwarder/0.1.0\r\n"
                "Accept: text/html,application/xhtml+xml\r\n"
                "Connection: close\r\n\r\n"
            )
            writer.write(request_text.encode("ascii"))
            await writer.drain()
            payload = await asyncio.wait_for(
                reader.read(-1),
                timeout=LANDING_PAGE_FETCH_TIMEOUT_SECONDS,
            )
        finally:
            writer.close()
            try:
                await writer.wait_closed()
            except Exception:
                pass
    finally:
        pass

    response = parse_http_response(payload)
    try:
        if response.status in {301, 302, 303, 307, 308}:
            location = response.headers.get("Location")
            if not location:
                raise URLError(f"redirect without location: {url}")
            return await fetch_landing_page_html_via_proxy(
                urljoin(url, location),
                proxy,
                redirect_limit=redirect_limit - 1,
            )

        if response.status >= 400:
            raise URLError(f"landing page returned HTTP {response.status}")

        body = response.read()
        content_encoding = (response.headers.get("Content-Encoding") or "").lower()
        if "gzip" in content_encoding:
            body = gzip.decompress(body)
        charset = response.headers.get_content_charset() or "utf-8"
        return body.decode(charset, errors="ignore")
    finally:
        response.close()


async def open_socket_via_proxy(
    proxy: ProxyConfig,
    *,
    host: str,
    port: int,
) -> socket.socket:
    if python_socks is not None:
        from python_socks import ProxyType
        from python_socks.async_.asyncio import Proxy

        proxy_type = normalize_python_socks_proxy_type(proxy.proxy_type, ProxyType)
        proxy_client = Proxy.create(
            proxy_type,
            proxy.host,
            int(proxy.port),
            proxy.username,
            proxy.password,
            bool(proxy.rdns),
        )
        return await proxy_client.connect(
            dest_host=host,
            dest_port=port,
            timeout=LANDING_PAGE_FETCH_TIMEOUT_SECONDS,
        )

    if socks is None:
        raise RuntimeError("landing page proxy support requires python_socks or PySocks")

    proxy_type = normalize_pysocks_proxy_type(proxy.proxy_type)
    proxy_socket = socks.socksocket(socket.AF_INET, socket.SOCK_STREAM)
    proxy_socket.set_proxy(
        proxy_type,
        proxy.host,
        int(proxy.port),
        rdns=bool(proxy.rdns),
        username=proxy.username,
        password=proxy.password,
    )
    proxy_socket.settimeout(LANDING_PAGE_FETCH_TIMEOUT_SECONDS)
    proxy_socket.setblocking(False)
    await asyncio.wait_for(
        asyncio.get_running_loop().sock_connect(proxy_socket, (host, port)),
        timeout=LANDING_PAGE_FETCH_TIMEOUT_SECONDS,
    )
    return proxy_socket


def normalize_python_socks_proxy_type(proxy_type: str, proxy_type_enum: object) -> object:
    text = str(proxy_type or "").strip().lower()
    if text == "socks5":
        return proxy_type_enum.SOCKS5
    if text == "socks4":
        return proxy_type_enum.SOCKS4
    if text == "http":
        return proxy_type_enum.HTTP
    raise ValueError(f"unsupported proxy type: {proxy_type}")


def normalize_pysocks_proxy_type(proxy_type: str) -> int:
    text = str(proxy_type or "").strip().lower()
    if text == "socks5":
        return socks.SOCKS5
    if text == "socks4":
        return socks.SOCKS4
    if text == "http":
        return socks.HTTP
    raise ValueError(f"unsupported proxy type: {proxy_type}")


def build_http_request_target(path: str, query: str) -> str:
    normalized_path = path or "/"
    if query:
        return f"{normalized_path}?{query}"
    return normalized_path


def parse_http_response(payload: bytes) -> HTTPResponse:
    class _MemorySocket:
        def __init__(self, data: bytes) -> None:
            self._buffer = io.BytesIO(data)

        def makefile(self, *args: object, **kwargs: object) -> io.BytesIO:
            return self._buffer

    response = HTTPResponse(_MemorySocket(payload))
    response.begin()
    return response


def extract_landing_page_values_from_html(html: str) -> list[str]:
    parser = LandingPageValueParser()
    parser.feed(html)
    parser.close()
    values = list(parser.values)
    values = apply_landing_page_extraction_rules(values)
    extra_urls: list[str] = []
    for item in values:
        extra_urls.extend(extract_urls_from_text(item))
    return dedupe_non_empty_strings(list(values) + extra_urls)


def normalize_url_for_request(url: str) -> str:
    raw_url = str(url or "").strip()
    if not raw_url:
        return raw_url
    parts = urlsplit(raw_url)
    if not parts.scheme or not parts.netloc:
        return raw_url
    safe_path = "/%:@!$&'()*+,;=-._~"
    safe_query = "&=%:@!$'()*+,;/?-._~"
    safe_fragment = "&=%:@!$'()*+,;/?-._~"
    return urlunsplit(
        (
            parts.scheme,
            parts.netloc,
            quote(parts.path, safe=safe_path),
            quote(parts.query, safe=safe_query),
            quote(parts.fragment, safe=safe_fragment),
        )
    )


def is_inspectable_landing_page_url(url: str) -> bool:
    return get_inspectable_landing_page_host(url) is not None


def get_inspectable_landing_page_host(url: str) -> str | None:
    try:
        parsed = urlparse(str(url or "").strip())
    except Exception:
        return None
    if parsed.scheme not in {"http", "https"}:
        return None
    host = (parsed.hostname or "").lower()
    landing_page_enabled, landing_page_hosts, _, _, _, _ = get_landing_page_behavior()
    if not landing_page_enabled:
        return None
    if host in landing_page_hosts:
        return host
    return None


def dedupe_non_empty_strings(values: list[object]) -> list[str]:
    result: list[str] = []
    seen: set[str] = set()
    for value in values:
        text = str(value or "").strip()
        if not text or text in seen:
            continue
        seen.add(text)
        result.append(text)
    return result


def apply_landing_page_extraction_rules(values: list[str]) -> list[str]:
    if not values:
        return []
    _, _, extract_mode, section_markers, stop_markers, fallback_to_full = get_landing_page_behavior()
    if extract_mode != LANDING_PAGE_EXTRACT_MODE_SECTION:
        return list(values)
    selected = extract_section_marker_values(values, section_markers, stop_markers)
    if selected:
        return selected
    if fallback_to_full:
        return list(values)
    return []


def extract_section_marker_values(
    values: list[str],
    section_markers: list[str],
    stop_markers: list[str],
) -> list[str]:
    normalized_markers = [normalize_marker_text(item) for item in section_markers if normalize_marker_text(item)]
    if not normalized_markers:
        return []
    normalized_stops = [normalize_marker_text(item) for item in stop_markers if normalize_marker_text(item)]
    ranges: list[tuple[int, int]] = []
    normalized_values = [normalize_marker_text(item) for item in values]

    for index, normalized_value in enumerate(normalized_values):
        if not normalized_value:
            continue
        if not any(marker in normalized_value for marker in normalized_markers):
            continue
        start = index
        if index > 0 and is_useful_section_neighbor(values[index - 1]):
            start = index - 1
        end = len(values)
        if normalized_stops:
            for stop_index in range(index + 1, len(values)):
                stop_value = normalized_values[stop_index]
                if stop_value and any(marker in stop_value for marker in normalized_stops):
                    end = stop_index
                    break
        ranges.append((start, end))

    if not ranges:
        return []
    merged_ranges = merge_index_ranges(ranges)
    selected: list[str] = []
    for start, end in merged_ranges:
        selected.extend(values[start:end])
    return dedupe_non_empty_strings(selected)


def merge_index_ranges(ranges: list[tuple[int, int]]) -> list[tuple[int, int]]:
    if not ranges:
        return []
    ordered = sorted(ranges)
    merged: list[tuple[int, int]] = [ordered[0]]
    for start, end in ordered[1:]:
        previous_start, previous_end = merged[-1]
        if start <= previous_end:
            merged[-1] = (previous_start, max(previous_end, end))
            continue
        merged.append((start, end))
    return merged


def normalize_marker_text(value: object) -> str:
    return re.sub(r"\s+", " ", str(value or "").strip().lower())


def is_useful_section_neighbor(value: object) -> bool:
    text = str(value or "").strip()
    if not text:
        return False
    lowered = text.lower()
    if extract_urls_from_text(text):
        return True
    return any(marker in lowered for marker in ("115cdn", "ed2k://", "magnet:", "thunder://"))


def dedupe_landing_page_references(values: list[LandingPageReference]) -> list[LandingPageReference]:
    result: list[LandingPageReference] = []
    seen_urls: set[str] = set()
    for item in values:
        url = str(item.url or "").strip()
        if not url or url in seen_urls:
            continue
        seen_urls.add(url)
        result.append(item)
    return result


def extract_urls_from_text(text: str) -> list[str]:
    if not text:
        return []
    raw_text = str(text)
    found: list[tuple[int, str]] = []
    seen: set[str] = set()
    for pattern in SPECIAL_URL_PATTERNS:
        for match in pattern.finditer(raw_text):
            value = match.group(0).strip()
            lowered = value.lower()
            if not value or lowered in seen:
                continue
            seen.add(lowered)
            found.append((match.start(), value))
    found.sort(key=lambda item: item[0])
    return [value for _, value in found]


class LandingPageValueParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.values: list[str] = []
        self._ignored_stack: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        lowered_tag = tag.lower()
        if lowered_tag in {"script", "style", "noscript"}:
            self._ignored_stack.append(lowered_tag)
            return
        attrs_map = {key.lower(): (value or "") for key, value in attrs}
        href = attrs_map.get("href", "").strip()
        if href:
            self.values.append(href)

    def handle_endtag(self, tag: str) -> None:
        lowered_tag = tag.lower()
        if self._ignored_stack and self._ignored_stack[-1] == lowered_tag:
            self._ignored_stack.pop()

    def handle_data(self, data: str) -> None:
        if self._ignored_stack:
            return
        text = str(data or "").strip()
        if text:
            self.values.append(text)
